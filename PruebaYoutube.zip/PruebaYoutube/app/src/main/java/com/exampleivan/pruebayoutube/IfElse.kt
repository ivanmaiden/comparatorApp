package com.exampleivan.pruebayoutube

fun main() {
    ifMultipleOr()
    ifMultiple()
    ifInt()
    ifBoolean()
    ifAnidado()
    ifBasico()


}
// Los dos palitos || es un or.
fun ifMultipleOr(){
    var pet= "cat"
    var itsHappy= true
    if (pet == "dog" || (pet == "cat" && !itsHappy))
        println(" Esto es un perro o un gato")
    else{
        println("Debe ser un Pokemon")
    }
}

// El && es and, como decir: esto y esto.
fun ifMultiple() {
    var age = 18
    var parentPermission = true
    var imHappy = true

    if (age >= 18 && parentPermission && imHappy)
        println("Puedo escabiar")
}

fun ifInt() {
    var age = 18
    if (age >= 18)
        println("Escabiate todo")
    else {
        println("Tomar juguito")
    }
}


//Cuando usamos un Boolean, si ponemos un signo de exclamacion significa que
//se expresa lo contrario. Si pedia un true, decimos que es false.
fun ifBoolean() {
    var soyFeliz: Boolean = false
    if (!soyFeliz) {
        println("Estoy triste")

    }
}


// Un igual (=) asigna valores, dos igual (==) comparan.
// El If anidado, -else if- sirve para comprobar entre valores.
fun ifAnidado() {
    val animal = "Pokemon"
    if (animal == "dog")
        println("Es un perro")
    else if (animal == "cat")
        println("Es un perro")
    else if (animal == "bird")
        println("es un pajaro")
    else {
        println("No es ninguno de los seleccionados")
    }
}


fun ifBasico() {
    val name = "ivan"
    if (name == "Leo")
        println("Hola amigooo")
    else {
        println("soy yo")
    }
}