package com.exampleivan.pruebayoutube

fun main(){
  mutableList()
   // inmutableList()
}
   fun mutableList() {
   val weekDays:MutableList<String> = mutableListOf("Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo")
       //weekDays.add(0"AristiDay")
       //println("Aristiday")

       if (weekDays.isEmpty()){
           println(weekDays)
            } else {weekDays.forEach{ println(it) }}

       if (weekDays.isNotEmpty()){
           weekDays.forEach { println(it) }
       }





   }




//* fun inmutableList(){
   // val readOnly:List<String> = listOf("Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo")
    //println(readOnly.size)
    //println(readOnly)
    //println(readOnly [2])
    //println(readOnly.last())
    //filtrar
    //val example = readOnly.filter { it.contains("e") }
    //println(example)

//    readOnly.forEach{diaDeLaSemana -> println(diaDeLaSemana) }
//}