package com.exampleivan.pruebayoutube

//Un arrays es un arreglo,una secuencia de datos

fun main(){
    val weekDays= arrayOf ("lunes", "martes", "miercoles", "jueves","viernes","sabado","domingo")
    println (weekDays [6])

    //Tamaños:
    // Si hago "println (weekDays [8])", me va a dar error. xq son solo 06 dias. para que no de error, se hace lo de abajo:
    if (weekDays.size >=8){
       println(weekDays [7])
         } else{
        println("no es un valor esperado")
        }
    println (weekDays.size)
    //Indice= 0-6
    //Tamaño= 7


    // Modificar valores
    weekDays [0]= "hola"
    println(weekDays [0])



    //Bucles para Arrays. Recorre todo el array.


    for(position in weekDays.indices){
        println(weekDays[position])
    }

    for ((position, value) in weekDays.withIndex())
        println("la posicion $position contiene el $value")

    for (titiwiti in weekDays [0])
        println("Ahora es $titiwiti")

}

