package com.exampleivan.pruebayoutube
fun main(){
    var name:String? = null
    println (name?.get (3) ?:"Es nulo")
}

//si no es nulo toma el 3, pero si lo es deci, es nulo.