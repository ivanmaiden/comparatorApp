package com.exampleivan.pruebayoutube.firstApp

fun main(){
    val txtUno = ""
    val txtDos = ""
    if(txtUno.isNotEmpty()==txtDos.isNotEmpty()){
        println("iguales")
    } else {
        println("no lo son")
    }

     }