package com.exampleivan.pruebayoutube

fun main(){
    getMonth(month = 2)
    getTrimester( trimester = 13)
    getSemester(semester= 403)
    result( true)
}
//Recibe un Int, devueve un String
// Si hay que anidar mas de un if, if else, if, se usa el When
// 1:51
//Rangos, para lo que esta entre y entre
// Any es para recibir cualquier cosa
fun result(value: Any){
    when (value){
        is Int-> value + value
        is String -> println("holiwi")
        is Boolean -> if (value)
            println("es value")
    }

}

fun getSemester (semester: Int){
    when (semester){
        in 1..400 ->println("primer año")
        in 401.. 402 -> println("segundo año")
        !in 1..402 -> println("no es un año valido")
    }

}

fun getTrimester(trimester: Int){
    when (trimester){
    1, 2, 3 -> println("Primer trimestre")

    4, 5, 6-> println("Segundo Trimestre")

    7, 8, 9-> println("Tercer trimestre")

    10, 11, 12-> println("Cuarto trimestre")
        else -> println("no es un trimestre valido")

    }


}
fun getMonth (month: Int){
    when(month){
        1-> println("enero")
        2-> println("febrero")
        3-> println("marzo")
        4-> println("abril")
        5-> println("mayo")
        6-> println("junio")
        7-> println("julio")
        8-> println("agosto")
        9-> println("sepiembre")
        10-> println("octubre")
        11-> println("noviembre")
        12-> println("diciembre")
        else ->println ("no es un mes")
    }
    }
