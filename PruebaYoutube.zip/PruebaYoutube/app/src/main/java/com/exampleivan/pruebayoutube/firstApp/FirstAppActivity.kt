package com.exampleivan.pruebayoutube.firstApp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import com.exampleivan.pruebayoutube.R
//Una clase es un contenedor de funciones
class FirstAppActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_app)
        val btnComp = findViewById<AppCompatButton>(R.id.btnComp)
        val etName = findViewById<AppCompatEditText>(R.id.etName)
        val etName2 = findViewById<AppCompatEditText>(R.id.etName2)
        val resultado= findViewById<TextView>(R.id.resultado)

        btnComp.setOnClickListener {

            val name= etName.text.toString()
            val name2= etName2.text.toString()


           if (name==name2){
               resultado.text= "Los caracteres coinciden"
               Log.i("pegarEnElLogcat","Los caracteres coinciden")
           } else {
               resultado.text= "Los caracteres NO coinciden"
               Log.i("pegarEnElLogcat", "Los caracteres No coinciden")

           }
        }


    }
}