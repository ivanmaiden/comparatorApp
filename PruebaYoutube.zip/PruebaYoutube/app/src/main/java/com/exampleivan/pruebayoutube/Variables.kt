package com.exampleivan.pruebayoutube

fun main() {
    showMyName("ivan")
    showMyAge(34) //esto es funcion con parametro de entrada
    add(4, 2)
    val mySubtract = subtract(10,5)
    println (mySubtract)
}

fun showMyName(name: String){
    println("me llamo $name")
}
// Atencion hay truco. El signo = al lado de Int deja por defecto un numero. eso es
// para evitar que no explote


fun showMyAge(currentAge: Int = 30) {
    //Con el signo $ cito!!!
    println("tengo $currentAge años")
}

fun add(firstNumber: Int, second: Int) {
    println(firstNumber + second)
}
//La funcion subtract es para que me devuelva algo, parametro de salida. El int especifica el
//parametro de entrada. Para especificar el parametro de salida, despues del parentesis pongo
//dos puntos, y otro Int, y poner Return. , xq voy a devolver un tipo Int.
fun subtract(firstNumber: Int, second: Int): Int {
    return firstNumber - second
}